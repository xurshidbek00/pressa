import logo from "../assets/Subtract.svg"
function Navbar() {
  return (
    <nav className="flex justify-between items-center  w-full h-[100px] p-[60px_80px_0_80px] bg-[#1E1E1E]">
      <div className=" items-center justify-center hidden sm:hidden md:hidden xl:flex 2xl:flex">
        <img src={logo} alt="" className="w-[67px] mr-[20px]" />
        <h1 className="text-[#c4c3c3] text-[48px] font-[Montserrat]"><b className="text-white">M</b>umair</h1>
      </div>
      <div className="flex justify-center items-center sm:items-center sm:justify-center lg:items-center lg:justify-center md:items-center md:justify-center font-[21px] font-[poppins] text-white w-[700px] sm:w-[800px] md:w-[900px] xl:h-[900px]">
        <div className=" flex justify-center items-center w-[700px]">
        <div><p className=" mr-[20px]">Home</p></div>
        <div><p className=" mr-[20px]">About Me</p></div>
        <div><p className=" mr-[20px]">Services</p></div>
        <div><p className=" mr-[20px]">Projects</p></div>
        <div><p className=" mr-[20px]">Testimonials</p></div>
        <div><p className=" mr-[20px]">Contact</p></div>
        <div className=" hidden sm:flex"><button className="w-[188px] h-[52px] bg-[#FD6F00] text-white font-[poppins] rounded-[5px]">Downlaod CV</button></div> 
          </div> 
      </div>
    </nav>
  );
}

export default Navbar;