import logo2 from "../assets/logo2.png"
import logo3 from "../assets/Rect.png"
import rest from "../assets/rect2.png"
import { FaFacebook } from "react-icons/fa"
import { Slider } from "@material-tailwind/react";
import { AiOutlineTwitter, AiOutlineInstagram, AiFillLinkedin } from "react-icons/ai"
import React from "react";
function Home() {
  return (
    <div className="w-[full] h-[100vh] flex justify-between items-center sm:justify-between sm:items-center p-[80px_80px_0_80px] flex-col">
      <div className="w-full h-[800px] flex">
        <div className="flex justify-center flex-col w-[800px] h-[700px]">
          <p className="text-white text-[24px] font-[poppins]">Hi I am </p>
          <p className="text-[#FD6F00] font-[poppins] mt-[10px] font-normal">Muhammad Umair </p>
          <h1 className="text-white text-[80px] font-[poppins]">UI & UX</h1>
          <h1 className="text-white text-[80px] ml-[180px] font-[poppins]">Designer</h1>
          <p className="text-white font-[poppins] text-[19px] w-[600px] mb-[40px]">Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra</p>
          <button className="w-[188px] h-[52px] bg-[#FD6F00] rounded-[5px] font-[poppins] text-white">Hire me</button>
        </div>

        <div className="w-[531px] h-[630px] md:w-[400px] md:h-[499px]  relative justify-center items-start mt-[100px] hidden sm:hidden  md:hidden lg:block xl:block 2xl:block ">
          <img src={logo2} alt="" className=" w-[410px] h-[490px]" />
          <div className=" absolute right-[10px] top-[75px]">
          <img src={logo3} alt="" />
        </div>
          <div className="flex w-full justify-center items-center m-[30px_30px_0_0]">
            <FaFacebook className="text-white text-[32px] m-[10px_30px_0_0]" />
            <AiOutlineTwitter className="text-white text-[32px] m-[10px_30px_0_0]" />
            <AiOutlineInstagram className="text-white text-[32px] m-[10px_30px_0_0]" />
            <AiFillLinkedin className="text-white text-[32px] m-[10px_30px_0_0]" />
          </div>
        </div>
      </div>
      {/* about me */}
      <div className="w-full h-[800px] flex justify-between items-center  ">
        <div className="w-[531px] h-[630px] relative justify-center items-center mt-[100px] hidden sm:hidden  md:hidden lg:block xl:block 2xl:block">
          <img src={rest} alt="" className=" w-[531px]" />
          <div className=" absolute top-[90px] left-[80px]">
          <img src={logo3} alt="" />
        </div>
        </div>
        

        <div className="w-[600px] h-[700px] flex justify-start mt-[200px] items-start flex-col">
          <h1 className="text-[65px] text-white">About Me</h1>
          <p className="text-[21px] font-[poppins] text-white">Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra</p>

          <div className="flex w-[484px] flex-col gap-5 mt-[30px]">
            <p className="text-white font-[poppins] text-[24px]">UX</p><Slider defaultValue={90} className="text-[#FD6F00]" />
            <p className="text-white font-[poppins] text-[24px]">Website Design</p><Slider className="text-[#FD6F00]" defaultValue={80} />
            <p className="text-white font-[poppins] text-[24px]">App Design </p><Slider className="text-[#FD6F00]" defaultValue={95} />
            <p className="text-white font-[poppins] text-[24px]">Graphic Design </p><Slider className="text-[#FD6F00]" defaultValue={90} />
          </div>
        </div>
      </div>
      {/* Servis */}
      <div className="flex flex-col justify-center items-center sm:justify-center sm:items-center md:justify-center md:items-center w-[800px] h-[590px] sm:w-[800px] ml-[500px] sm:ml-0 md:ml-0 lg:ml-0 ">
        <h1 className="text-white font-[poppins] text-[40px]">Services</h1>
        <p className="text-white fotn-[poppins] text-[21px] w-[400px] sm:w-[550px] md:w-[700px] text-center mt-[40px]">Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium</p>
      </div>
    </div>
  );
}

export default Home;